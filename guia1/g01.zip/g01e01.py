# Pedir dos números enteros, sumarlos y mostrar el resultado.
numero1 = input('Ingrese un numero entero:')
numero2 = input('Ingrese otro numero entero:')

numero1 = int(numero1)
numero2 = int(numero2)
print(numero1+numero2)