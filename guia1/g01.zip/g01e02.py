# Pedir tres notas, calcular el promedio y mostrarlo.
nota1 = input("Inserte la primer nota: ")
nota2 = input ("Inserte la segunda nota: ")
nota3 = input ("Inserte la tercer nota: ")

nota1 = int(nota1)
nota2 = int(nota2)
nota3 = int(nota3)

promedio = (nota1 + nota2 + nota3)/ 3

print(promedio)