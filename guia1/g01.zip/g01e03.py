# Leer un número real y emitir una leyenda informando si es mayor o igual a cero o bien es negativo (son dos opciones).

numero = float(input("ingrese un numero real:"))

if  numero >= 0:
    print('el numero es mayor o igual a cero')
else:
    print('el numero ingresado es negativo')