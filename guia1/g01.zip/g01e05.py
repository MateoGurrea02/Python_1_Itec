# Leer dos números reales y mostrarlos en orden creciente
numero1 = float(input("ingrese un numero"))
numero2 = float(input("ingrese otro numero"))

if numero1 > numero2:
    print(numero2, numero1)
else:
    print(numero1, numero2)